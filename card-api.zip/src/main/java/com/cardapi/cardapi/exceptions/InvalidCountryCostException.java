package com.cardapi.cardapi.exceptions;

public class InvalidCountryCostException extends IllegalArgumentException {
    public InvalidCountryCostException(String m) {
        super(m);
    }
}
