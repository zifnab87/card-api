package com.cardapi.cardapi.exceptions;

public class OthersCostCantBeDeletedException extends IllegalArgumentException {
    public OthersCostCantBeDeletedException(String m) {
        super(m);
    }
}
